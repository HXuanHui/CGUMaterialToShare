#include <iostream>
#include <cstring>
#include <vector>
#include <algorithm>
using namespace std;

void parse(const string& line);
void executeTokens();
bool isNum(const string& token);
void addHandler();
void subHandler();
void lwHandler();
void swHandler();

vector<string> reserved = {"add","sub","lw","sw"};
/*zreo,for IType const,arguments,temp,contents for later,temp,OS,...*/
vector<string> reg = {"$zero","$at"\
                      ,"$v0","$v1"\
                      ,"$a0","$a1","$a2","$a3"\
                      ,"$t0","$t1","$t2","$t3","$t4","$t5","$t6","$t7"\
                      ,"$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7"\
                      ,"$t8","$t9"\
                      ,"$k0","$k1"\
                      ,"$gp","$sp","$fp","$ra"};
  vector<string> tokens;
  vector<string> component;

int main() {
  string line = "";
  while(true){
    cout<<"Please enter MIPS instruction:"<<endl;
    getline (cin,line);
    parse(line);
    executeTokens();
    // for(int i =0 ;i<tokens.size();i++){
    //   cout<<tokens[i];
    //   cout<<component[i]<<endl;
    // }
    line = "";
    tokens.clear();
    component.clear();
  }
  return 0;
}
bool isNum(const string& token){
  for (char const &ch : token) {
    if (std::isdigit(ch) == 0)
        return false;
  }
  return true;
}
void parse(const string& line){  //split and classify op or reg
  char* charLine = new char[line.length()+1];  //generate line long char array
  strcpy(charLine,line.c_str());  //string to char
  
  const char* pattern = " ,()";
  char* splited;
  splited = strtok(charLine,pattern);

  bool op = false;
  while(splited){
    string strSplited = splited;
    tokens.push_back(strSplited);
    splited = strtok(NULL,pattern);

    if(op != true){
      op = true;
      vector<string>::iterator find_resvd = std::find(reserved.begin(),reserved.end(),strSplited);  
      if(find_resvd != reserved.end()){
        component.push_back("RESVD");
      }
      else{
        cout<<"Error: Unknown command "<<strSplited<<endl;
        component.push_back("Unknown");
      }
    }
    else{
      vector<string>::iterator find_reg = std::find(reg.begin(),reg.end(),strSplited); 
      if(find_reg != reg.end()){
          component.push_back("REG");
      }
      else if(isNum(strSplited)){
        component.push_back("NUM");
      }
      else{
        cout<<"Error: Unknown operand "<<strSplited<<endl;
        component.push_back("Unknown");
      }
    } 
  }
}
void executeTokens(){
  if(component[0] == "RESVD"){
    for(int i = 0; i < tokens.size(); i++){
      if(tokens[i] == "add"){
        addHandler();
      }
      else if(tokens[i] == "sub"){
        subHandler();
      }
      else if(tokens[i] == "sw"){
        swHandler();
      }
      else if(tokens[i] == "lw"){
        lwHandler();
      }
    }
  }  
}
void addHandler(){
  if(tokens.size()<4){
    cout<<"Error: Malformed add statement, lack of register."<<endl;
  }
  else{
    for(int i=1;i<=3;i++){
      if(component[i]!="REG"){
        cout<<"Error: Malformed add statement, no suitable register "<<tokens[i]<<endl;
        return;
      }
    }
    cout<<"Instruction: "<<tokens[0]<<endl;
    cout<<"Source operands: "<<tokens[2]<<" "<<tokens[3]<<endl;
    cout<<"Destination operand: "<<tokens[1]<<endl;
  }    
}
void subHandler(){
  if(tokens.size()<4){
    cout<<"Error: Malformed sub statement, lack of register."<<endl;
  }
  else{
    for(int i=1;i<=3;i++){
      if(component[i]!="REG"){
        cout<<"Error: Malformed sub statement, no suitable register "<<tokens[i]<<endl;
        return;
      }
    }
    cout<<"Instruction: "<<tokens[0]<<endl;
    cout<<"Source operands: "<<tokens[2]<<" "<<tokens[3]<<endl;
    cout<<"Destination operand: "<<tokens[1]<<endl;
  }    
}
void lwHandler(){
  if(tokens.size()<4){
    cout<<"Error: Malformed lw statement, lack of register."<<endl;
  }
  else{
    if(component[1]!="REG"||component[3]!="REG"){
      cout<<"Error: Malformed lw statement, no suitable register."<<endl;
      return;
    }
    if(component[2]!="NUM"){
      cout<<"Error: Malformed lw statement, wrong distance "<<tokens[2]<<endl;
      return;
    }
    cout<<"Instruction: "<<tokens[0]<<endl;
    cout<<"Source operand: "<<tokens[3]<<endl;
    cout<<"Destination operand: "<<tokens[1]<<endl;
    cout<<tokens[1]<<" <- Mem["<<tokens[3]<<"+"<<tokens[2]<<"]"<<endl;
  }   
}
void swHandler(){
  if(tokens.size()<4){
    cout<<"Error: Malformed sw statement, lack of register."<<endl;
  }
  else{
    if(component[1]!="REG"||component[3]!="REG"){
      cout<<"Error: Malformed sw statement, no suitable register."<<endl;
      return;
    }
    if(component[2]!="NUM"){
      cout<<"Error: Malformed sw statement, wrong distance "<<tokens[2]<<endl;
      return;
    }
    cout<<"Instruction: "<<tokens[0]<<endl;
    cout<<"Source operands: "<<tokens[1]<<" "<<tokens[3]<<endl;
    cout<<"Mem["<<tokens[3]<<"+"<<tokens[2]<<"] <- "<<tokens[1]<<endl;
  }
}
